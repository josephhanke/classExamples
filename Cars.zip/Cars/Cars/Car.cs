﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cars
{
    public class Car
    {
        public string Make;
        public string Model;
        public int Year;
        public string Color;

        public double DetermineMarketValue()
        {

            double carValue;

            if (this.Year > 1990)            
                carValue = 3860.0;          

            else
                carValue = 2000.0;

            return carValue;

        }

     }
}

