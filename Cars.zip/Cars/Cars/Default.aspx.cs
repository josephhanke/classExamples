﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Cars
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Car myNewCar = new Car();

            myNewCar.Make = "Tesla";
            myNewCar.Model = "S";
            myNewCar.Year = 2017;
            myNewCar.Color = "Silver";

            double myMarketValueofCar = myNewCar.DetermineMarketValue();

            resultLabel.Text = String.Format("{0} - {1} - {2} - {3} - {4:C}",
                myNewCar.Make,
                myNewCar.Model,
                myNewCar.Year.ToString(),
                myNewCar.Color,
                myMarketValueofCar);                     
                                

         }


    }
}

   




